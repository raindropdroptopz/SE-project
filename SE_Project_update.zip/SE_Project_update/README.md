# SE-Project
### Projectplan
- Agile
- Waterfall

### งานที่ต้องทำ ต้องภายในวันพฤหัส
- [x] Login (ข้างการเชื่อมกับSQL(XAMPP))
- [x] ตกแต่งหน้าLogin (in process)
- [x] หน้าต่างเลือกจอง (สนาม, อุปกรณ์)
- [x] Register
- [x] หน้าต่างการจองสนาม & อุปกรณ์
- [ ] data flow
- [ ] Back-End
- [ ] เชื่อมกับSQL

### Diagram
- [ ] DFD level 1 (Data Flow)
